# Frozen Batch B seven-failure fixture and diagnostic repair

## Scope and identity
- Parent/assembler-assigned seven-failure cluster; root owns shared setting, SessionObjects and quarantine phases separately in9fab4cde.
- Base:d1b9c1c630649ab5ffa9aed250260b979f556f71.
- Head:7796192368509205dc26ade39cc3bdf622a71271.
- Tree:c2cfa76540e85d6d5ea64d7c440aaa2ecbfafe01.
- Worktree/branch:/private/tmp/cassie-queued-cleanup-fixture-repair-20261116,codex/queued-cleanup-fixture-repair-20261116.
- Only assigned fixture/hooks/private watchdog paths changed. Product/runtime ownership paths, native APIs, CI/version/release, standing assertions/gates remain unchanged.

## Observed evidence
- Full assembler test attempt on d1b9c1c6: exit101,3904 unit tests passed/10 failed,139.58s test execution/473.32s command. Source/log:/private/tmp/cassie-all-open-runtime-integration-20261116/target/assembly-line/runtime-closeout/{test-2.log,test-2-failures.txt}.
- Owned seven failures: queued cleanup blocker timeout then release SendError; four EXPLAIN/pgwire capture-wait watchdog timeouts; clock CALL fixture Unsupported inside active transaction; COPY watchdog child101.
- Assembler direct-existing-binary COPY child diagnostic failed0.023s at the old exact division-by-zero assertion, with real result unprinted. Receipt/output: runtime-closeout/copy-child-diagnostic/{receipt.json,output.log}. Do not report old result25000 as observed;25000 is the source-backed selected repaired oracle.
- These are observed executable REDs. Repaired or newly enhanced tests remain NOT RUN; no green claimed and coder ran no Cargo.

## Coder handoff
- Queued cleanup: startup/SQL fixture and actual defer_drop_collection marker created before occupying the sole Tokio blocking slot. Explicit cfgtest abort-request notification arrives after worker.abort; only then release occupied pool, then await canceled boundary. This avoids awaiting queue retirement while blocking the only dequeue thread. Original StorageRetryable/no operation/no cleanup assertions stay. Actual cleanup marker must remain identical after cancellation; a later normal owned worker must reclaim it. Existing10s hang guards unchanged.
- Four capture timeout controls: new optional test-only pause after the actual failed try-lock. Coordinator observes root still held, releases and joins holder, performs real later statement_timeout write through guarded API, then resumes capture. Original enabled/disabled snapshot boolean, current owner, healthy/success assertions remain. No production admission/timing changes or deadline widening. Unused older pgwire contention installer removed after its only caller moved to paused form.
- Clock: preserve test name; replace unsupported explicit-transaction CALL with supported standalone procedure INSERT(now(),now()) into a probe table, observe equal values externally because CALL discards body result. Seeded inactive shared clock remains unchanged; Idle/healthy assertions added. All active-root/fork clock controls unchanged.
- COPY: preserve original after-owner-check A→B schedule/name and all B healthy/usable/identity assertions. Selected stronger stale operation contract requires exact25000 before predicate evaluation; add Debug result for future diagnostics. Identical same-owner predicate test still requires division by zero. No generic-error weakening.
- Watchdog: private piped stdout/stderr each has one owned draining reader. Retain only16KiB tail per stream while draining all bytes to prevent pipe backpressure; no unbounded memory/file capture. Owned child is killed/reaped before reader joins on timeout/drop. Existing30s deadline/check interval/status/START+COMPLETE receipts remain. Failed child/receipt/timeout messages now include bounded tails. New bounded-tail oracle and strengthened existing missing-child diagnostic assertions are unrun.
- Authorship: original seven controls already existed before observed RED; repairs strengthen actual boundary/debt diagnostics. New output-cap control authored before output capture implementation. No baseline passing reconstruction.
- Direct rustfmt on owned paths and git diff --check passed. No Cargo/build/test/Clippy/benchmark/full format/test policy by coder.

## Review handoff
- Jev selected runtime fixture repairs1.0; exact stale COPY25000 .95. Source receipts runtime-failure-contracts-* under reviewer ignored target/assembly-line/all-open-review.
- Exact77961923/head/tree sent for affected source review; pending disposition.

## Assembly and integrated review
- Cherry-pick77961923 only onto d1b9c1c6 or equivalent integrated source, combine root9fab4cde disjoint repair.
- New source module: app/query_failure_watchdog/output.rs with one unit control; assembler owns inventory refresh and final combined source review.
- Affected focused selectors (assembler only): blocking::tests::should_leave_cleanup_debt_for_later_when_a_queued_worker_never_starts; temporal_context::tests::should_preserve_now_through_an_actual_nested_procedure_call; four named preserve_enabled/disabled_{explain,pgwire}_timeout_during_capture_wait; copy::origin_failure_authority_tests::; query_failure_watchdog::.
- Full ordered checks and exact feature probes repeat as required on corrected frozen source. Do not label the previous failed run as passed.

## Qualification and publication
- Corrected build/tests/strict Clippy/format/test policy/inventory/hosted checks pending assembler.
- No push/PR/merge/issue closure or final qualification by coder.
- C benchmark campaign remains read-only reconnaissance; no C implementation mixed into this repair.
