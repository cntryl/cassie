# Frozen B warning cleanup

## Scope and identity
- Assembler-assigned five warning groups from successful build2 at23b78f61.
- Worktree/branch:/private/tmp/cassie-runtime-dead-code-repair-20261116,codex/runtime-dead-code-repair-20261116.
- Base23b78f61; headd5497d59a71ea01c6a71b626f5902819ac299af4; tree173079282299a2768b4759af655c490ae52b9693.

## Coder handoff
- Only five assigned files changed: session/wire_failure.rs, transaction_control.rs, transaction_origin.rs, session_sequences.rs, pgwire/connection/state.rs.
- Zero callers of try_with_owned_transaction across src/tests/benches: superseded method removed.
- try_with_owned_idle_transaction has one existing unit assertion: cfg(test), existing assertions retained.
- with_root_transaction_status_locked is called only from legacy discard test support: cfg(test).
- begin_implicit_transaction wrapper has only unit fixture callers; production uses begin_implicit_transaction_for_operation: wrapper cfg(test).
- discard_sequence_values and inner have only owning unit fixture/observed-helper callers: cfg(test), remove the now unreachable non-test branch from the test-only implementation.
- clear_all_portals has only cfg(test) clear_idle_portals caller: cfg(test).
- Exact post-edit source/tests/benches caller census in callers.txt. No ignores/lint-level changes, no production ownership bypass, no test/assertion changes.
- Observed assembler build2 passed31.88s with warnings; log:/private/tmp/cassie-all-open-runtime-integration-20261116/target/assembly-line/runtime-closeout/build-2.log. This is not a regression RED. Tests have not run.
- Direct rustfmt only owned five files plus git diff --check passed. No Cargo by coder.

## Review and assembly
- Scope accepted by reviewer; exact immutable diff sent for source review before next frozen build.
- Cherry-pick d5497d59 only after23b78f61; assembler owns compilation and complete ordered gate.

## Qualification and publication
- Corrected build/test/strict Clippy/format/testpolicy/inventory/hosted checks remain pending.
- No push/PR/merge/issue closure/qualification by coder.
