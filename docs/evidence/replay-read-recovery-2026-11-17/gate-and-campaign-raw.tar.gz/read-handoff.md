# Batch C finite replay reads and operator profile clarity

## Scope and identity
- Coder-owned source freeze; coordinator /root; reviewer /root/review; assembler /root/assembler.
- Objective: #1271 separately timed representative reads with exact correctness and real index/scan attestation, and honest operator profile diagnostics.
- Base 056872b4a57caf67d2b0222d3b05e9415a0c2609; branch codex/replay-read-campaign-20261116; worktree /private/tmp/cassie-replay-read-campaign-20261116.
- Prerequisites: historical A API receipts exist at58e6c96ea14c3466da17c256cb2fcaefbd71f940/treed051222b580d48266b3ed604f588928bd443e660; final B qualification and new SQL writer receipts remain pending. Reader cannot claim results until those are complete.
- Canonical docs: docs/performance-contracts.md; sql-replayable-transaction-contract.md; projection-replay-contracts.md; new projection-replay-profiles.md.
- Exclusions: no storage engine/planner/runtime/product API/CI/version changes; no write matrix rerun; no original-engine open; no policy receipt invented from SHOW or aggregate counters.

## Coder handoff
- Immutable ordered range a8211cbd14b6a602239794b6f40c8b55d65478d3 then 58e1b5ca1cd337733659ddf118215d5367b3c0d7; final tree2a673001d2a39ae12ab53c0222c1096bf77f6018.
- Owned paths: benches/tier3_replay_durability.rs; benches/tier3_replay_durability/read_campaign.rs; benches/tier3_replay_durability/read_campaign/store_copy.rs; tests/bench_diagnostics/replay_read_ownership.rs; benches/tier3_replay_durability/read_campaign/read_oracle.rs; docs/benchmarks.md; docs/projection-replay-profiles.md.
- Regression-first: owning contract written first, then six helper controls, then implementation. All new controls authored/not run; no baseline executable RED claimed.
- Controls (under assembler module replay_read_ownership): should_copy_only_into_a_distinct_owned_directory_and_leave_source_bytes_unchanged; should_reject_a_foreign_writer_even_when_its_artifact_hashes_match; should_reject_missing_or_unsuccessful_clean_close_evidence_before_copying; should_reject_a_symlink_inside_an_otherwise_verified_closed_source (unix); should_reject_a_changed_original_after_the_owned_reader_copy_is_prepared; should_reject_a_mismatched_raw_receipt_or_original_fingerprint.
- Shared registration assembler-owned: add #[path="bench_diagnostics/replay_read_ownership.rs"] mod replay_read_ownership; to tests/bench_diagnostics.rs and update static inventory. Exact focused selector: cargo test --locked --test bench_diagnostics replay_read_ownership::.
- Campaign: CASSIE_REPLAY_BENCH_READ_MANIFEST=/absolute/read-manifest.json cargo bench --locked --features replay-benchmark-observation --bench tier3_replay_durability. Ordinary writer path unchanged when absent. Source-only preparation utility CASSIE_REPLAY_BENCH_SOURCE_FINGERPRINT=/closed/store uses same readonly helper algorithm; not closure proof.
- 8profiles: A API strict/buffered x indexed/unindexed plus qualified B SQLdefault/replayable x indexed/unindexed, all100k/1000x100. Warmup17 then3x17 timed=51/profile408total; equalityN48,countN3; countp95 explicitly maximum, no stable population claim.64MiB120s perquery/cacheoff.
- Timer excludes plans/metrics/correctness/copy/startup; SQL materialization included. Raw stdout retains every SQL and sample before propagating path/correctness error; per-profile gaps fail campaign.
- Oracles: all16 exact6250 title buckets+independentCOUNT100k; catalog/native index definitions agree; indexed public selected-name/noFallback plus actual read counters/lastindex/no collectionscan; unindexed actualscan/no index ops. No hints or planner repair if real fallback occurs.
- Provenance: manifest exactreader/writer/build labels distinct; all8 verified JSON/log/closure SHA256 and source profile constraints before anycopy. Caller-verified producerexit0/cleanclose bound towriter+storage+rawhashes; caller mustprevent lateropeners. Never infer closure from absentlock or mutateoriginallease. Fullpath/type/length/filehash original fingerprint before/afterbytecopy/afterreaderDrop. OwnedTempDir bytecopies with distinctinode, nohardlinks/symlinks; cleanup onlyownedcopy. Caller labels are not self-attested binary identity.
- Doc construction examples reference actualA archive1000x100-repeat1-{indexed|unindexed}-{local_strict|local_buffered}-apply.json/.log plus apply-matrix-exit0/hashmanifest/sourceevidence. SQLB exactwriter/exit/closure explicitlypending, no historicalASQLsubstitution.
- Actual validation: directrustfmt(skip_children) and git diff --check passed; no Cargo/build/test/Clippy/benchmark/qualification bycoder. Allnewexecution evidence pending.
- Limitations: real indexed planner/path mayfail attestation; report gap honestly. Copies/hash/warmup affect caches, no coldIO claim. No engine crash/cloud/powerloss/multi-host proof. Source closure requires trusted operator exclusion, not algorithmically detectable.

## Review handoff
- Exact immutable source review requested; Jev selections finite8/3rounds/copyclosure/pathattestation recorded by reviewer. All modelgap-required controls remain unrun pending combined gate.

## Assembly and qualification
- Integrate with parent-owned disjoint cloudC only after review; assembler owns registration, inventory and completeorderedgates, actualSQLwriter receipts and campaign execution, final integrated review and publication. No PR/push/merge bycoder.

## Exact review repair increment
- Review selected identity oracle .96, canonical dedup .92, drop wording .98; owning doc updated before dependent edits.
- Two further controls authored first: should_reject_duplicate_row_ids_even_when_bucket_titles_and_counts_match (minimal2row duplicate +positive2 +acrossbucket duplicate); should_reject_alias_paths_reusing_the_same_original_before_copying. Eight controls total, selector unchanged, all authored/not run.
- Actual SELECT id,title returns6250distinct IDs per bucket and100kdistinct IDs perround, checked outside timer through shared read_oracle helper; COUNT remains independent100k. Raw per-query attestation records round_unique_ids.
- All selected source directories canonicalized/claimed before any copy; dot/parent aliases reject. Original receipts still verified first.
- All raw after_reader_close fields renamed after_reader_drop. Explicit raw/doc retirement scope is Cassie drop/graceful-close attempt, native quiescence NOT attested; original hash equality afterDrop does not claim engine threads retired.
- Same8profiles,17warmup+51timedqueries/profile; no additional throughput correctness workload. No Cargo; directrustfmt/diffcheck passed afterrepair. Exact affected source re-review pending.
