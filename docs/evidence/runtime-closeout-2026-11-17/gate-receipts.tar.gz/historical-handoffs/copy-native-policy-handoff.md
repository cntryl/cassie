# Batch B final COPY native-policy probe

## Scope and identity

- Owner: coder; parent-assigned final original #1279 qualification gap. No Cargo execution.
- Baseline:60e62fc6 (assembler frozen runtime integration metadata head).
- Worktree/branch:/private/tmp/cassie-copy-native-policy-probe-20261116, codex/copy-native-policy-probe-20261116.
- Head:da05f1bc12624027b0c115b896e668e0f1c9121c.
- Tree:b1f9436162096e35a2b4a3cbb0e1dd7a467a813c.
- Contract: docs/sql-replayable-transaction-contract.md actual wire COPY policy probe, existing native metrics and published cntryl-midge0.5.2. No CI/version/release/upstream engine change.
- Jev selected add_actual_worker_policy1.0; actual owning Data callback, not aggregate first outside-maintenance policy.

## Coder handoff

- Commit:da05f1bc, one focused increment based directly on60e62fc6.
- Owned paths: new src/pgwire/connection/copy/native_policy_tests.rs; minimal cfgtest/feature wiring copy.rs and blocking.rs; new src/midge/adapter/transactions/data_policy_test_observer.rs; transactions.rs native row callback; existing native commit function extracted unchanged to transactions/native_commit.rs to retain source size991; three-line cfgtest adapter/mod.rs reexport (registration assignment requested from parent).
- Tests authored BEFORE observer/hook implementation; every control is authored/not run. No observed RED/green claimed.
- Exact feature selector: cargo test --locked --lib --features replay-benchmark-observation pgwire::connection::copy::native_policy_tests:: -- --nocapture
- Tests:
  - should_use_strict_native_data_policy_for_default_wire_copy_and_checkpoint
  - should_use_buffered_native_data_policy_for_replayable_wire_copy_and_checkpoint
  - should_promote_replayable_wire_copy_with_a_sequence_default_to_strict_data_policy
- Real owned-listener/memory-mode authenticated wire flow stages COPY41 and checkpoint7 in an explicit block. Observer session sees neither before COMMIT and both after. Sequence-default case asserts assignedid1.
- Observation is armed after staging and keyed to exact Cassie runtime plus pgwire_simple_query. The actual blocking worker wraps its operation in existing aggregate native metrics. Inside publication.publish_rows_current callback, after staging/suppression/permission, test-only Data observer wraps the native submit and records its actual result. First owning Data policy is asserted independently from overall first native policy/schema epoch/maintenance metrics. Reactor and worker thread IDs differ.
- Pure cfg(all(test,feature)) observation adds no production telemetry/semantics; native commit function extraction preserves existing suppressed/unknown injection/native metrics logic. Memory-mode policy selection does not prove persistent durability or crash safety.
- Actual validation: direct rustfmt --edition2021 --config skip_children=true on owned paths and git diff --check passed. Cargo/build/test/Clippy/fullformat/testpolicy not run; assembler only.

## Review handoff

- Exact immutable head/tree above source/Jev accepted by /root/review pending execution: integrate_pending_execution .99; Data attribution gap .07, extraction .09, probe .26. No additional scope/filter requested.
- Reviewer receipt root:/private/tmp/cassie-review-all-20261116/target/assembly-line/all-open-review; semantic decision integrated-copy-policy-probe-*.
- Any repair changes invalidate this exact review identity. Return source/probe defects to coder; no assertion weakening.

## Assembly and integrated review

- Cherry-pick da05f1bc only onto assembler60e62fc6 or later equivalent metadata head.
- Update assembler-owned test inventory for new module/feature controls. Registration reexport is minimal wiring; no substantive feature code added to existing oversized adapter/mod.rs.
- Obtain affected review before the coherent complete B gate, then execute these exact3controls with all standing B probes/required ordered gates.

## Qualification and publication

- Build, complete locked tests, strict all-target/all-feature Clippy, full format/test policy/inventory, final-head hosted checks: NOT RUN for this increment.
- No push/PR/merge/issue closure by coder. Parent/assembler own final publication and acceptance evidence.
