//! Temporary, read-only-original metadata probe. Not a normalization repair.
#[path = "../../../benches/tier3_replay_durability/read_campaign/store_copy.rs"]
mod store_copy;

use cassie::app::Cassie;
use cassie::config::{CassieRuntimeConfig, CassieRuntimeLimits, ExecutionResultCacheEnabled};
use serde::Deserialize;
use serde_json::json;
use std::collections::BTreeSet;
use std::path::Path;
use store_copy::{OwnedCopy, ProfileFiles, SourceIdentity, VerifiedSource};

type Result<T> = std::result::Result<T, String>;

#[derive(Deserialize)]
struct Manifest {
    api_writer: SourceIdentity,
    sql_writer: SourceIdentity,
    profiles: Vec<ProfileFiles>,
}

struct Engine(Cassie);
impl Drop for Engine {
    fn drop(&mut self) {
        self.0.shutdown();
    }
}

fn metadata(path: &Path) -> Result<serde_json::Value> {
    let config = CassieRuntimeConfig {
        limits: CassieRuntimeLimits {
            query_memory_budget_bytes: 64 * 1024 * 1024,
            query_timeout_ms: 120_000,
            execution_result_cache_enabled: ExecutionResultCacheEnabled::disabled(),
            ..CassieRuntimeLimits::default()
        },
        ..CassieRuntimeConfig::default()
    };
    let engine = Engine(
        Cassie::new_local_with_data_dir_and_config(path, config)
            .map_err(|error| error.to_string())?,
    );
    let cassie = &engine.0;
    cassie.startup().map_err(|error| error.to_string())?;
    let collection = cassie.midge.canonical_collection_name("replay_bench");
    let catalog_collection = cassie.catalog.get_collection(&collection);
    let native_collection = cassie
        .midge
        .collection_metadata(&collection)
        .map_err(|error| error.to_string())?;
    let catalog_indexes = cassie.catalog.list_indexes(&collection);
    // Print every native index as well as its target flag, so filtering cannot hide a mismatch.
    let native_indexes = cassie
        .midge
        .list_indexes()
        .map_err(|error| error.to_string())?;
    let native_id_observations = native_indexes.iter().map(|index| json!({
        "collection": index.collection, "name": index.name,
        "target_collection": cassie.midge.canonical_collection_name(&index.collection) == collection,
        "relation_id_raw": index.options.get("__cassie_relation_id"),
        "storage_id_raw": index.options.get("__cassie_storage_id")
    })).collect::<Vec<_>>();
    Ok(json!({
        "collection": collection,
        "catalog_collection_storage_id": catalog_collection.as_ref().map(|item| item.storage_id),
        "native_collection_storage_id": native_collection.as_ref().map(|item| item.storage_id),
        "catalog_collection": catalog_collection, "native_collection": native_collection,
        "catalog_indexes": catalog_indexes, "native_indexes": native_indexes,
        "native_id_observations": native_id_observations
    }))
}

fn inspect(source: &VerifiedSource, manifest_sha256: &str) -> Result<()> {
    let before = store_copy::fingerprint(&source.result.storage_path)?;
    let copy = OwnedCopy::prepare(source)?;
    let after_copy = store_copy::fingerprint(&source.result.storage_path)?;
    let observed = metadata(copy.path());
    // metadata returns only after Engine drop/graceful-close attempt; no quiescence claim.
    let after_drop = store_copy::fingerprint(&source.result.storage_path)?;
    let unchanged = copy.verify_original().and_then(|()| {
        if before == source.files.source_fingerprint && before == after_copy && before == after_drop
        {
            Ok(())
        } else {
            Err("original fingerprints differ around diagnostic".into())
        }
    });
    println!(
        "{}",
        json!({
            "kind": "index_metadata_diagnostic", "manifest_sha256": manifest_sha256,
            "mode": source.result.mode, "shape": source.result.shape,
            "writer": source.writer, "receipts": source.files,
            "original_path": source.result.storage_path, "opened_copy_path": copy.path(),
            "original_fingerprint_before_copy": before,
            "original_fingerprint_after_copy": after_copy,
            "original_fingerprint_after_reader_drop": after_drop,
            "original_unchanged": unchanged.is_ok(),
            "metadata": observed.as_ref().ok(), "metadata_error": observed.as_ref().err(),
            "original_verification_error": unchanged.as_ref().err(),
            "reader_retirement_scope": "Cassie drop/graceful-close attempt; native quiescence not attested"
        })
    );
    observed?;
    unchanged?;
    Ok(())
}

fn main() -> Result<()> {
    let manifest_path = std::env::args_os().nth(1).ok_or("expected manifest path")?;
    let path = Path::new(&manifest_path);
    let manifest_sha256 = store_copy::sha256_file(path)?;
    let manifest: Manifest =
        serde_json::from_reader(std::fs::File::open(path).map_err(|error| error.to_string())?)
            .map_err(|error| error.to_string())?;
    if manifest.api_writer.commit != "58e6c96ea14c3466da17c256cb2fcaefbd71f940"
        || manifest.api_writer.tree != "d051222b580d48266b3ed604f588928bd443e660"
        || manifest.profiles.len() != 8
    {
        return Err("expected selected eight-profile manifest and exact API writer".into());
    }
    let mut sources = Vec::new();
    let mut originals = BTreeSet::new();
    let mut cells = BTreeSet::new();
    // Verify all receipt chains and canonical source identities before any new copy.
    for files in &manifest.profiles {
        let source = store_copy::load_profile(files, &manifest.api_writer, &manifest.sql_writer)?;
        store_copy::claim_original(&source.result.storage_path, &mut originals)?;
        if !cells.insert((source.result.mode.clone(), source.result.shape.clone())) {
            return Err("duplicate profile cell".into());
        }
        sources.push(source);
    }
    let mut failures = Vec::new();
    for source in sources
        .iter()
        .filter(|source| source.result.shape == "indexed")
    {
        if let Err(error) = inspect(source, &manifest_sha256) {
            failures.push(format!("{}: {error}", source.result.mode));
        }
    }
    if failures.is_empty() {
        Ok(())
    } else {
        Err(failures.join("; "))
    }
}
