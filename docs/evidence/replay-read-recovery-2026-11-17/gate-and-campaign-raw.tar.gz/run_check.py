from pathlib import Path
import datetime, json, os, subprocess, sys, time
root = Path.cwd()
receipt_root = root / 'target/assembly-line/replay-qualification'
name, *command = sys.argv[1:]
if not command:
    raise SystemExit('provide check name and exact command')
receipt = {
    'command': command,
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
    'dirty': subprocess.check_output(['git', 'status', '--porcelain'], text=True),
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'running',
}
record_path = receipt_root / f'{name}.json'
log_path = receipt_root / f'{name}.log'
record_path.write_text(json.dumps(receipt, indent=2)+'\n')
print(f"START {name} source={receipt['head']} command={command}", flush=True)
start = time.monotonic()
with log_path.open('w') as log:
    proc = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=os.environ.copy())
    code = proc.wait()
receipt.update(status='passed' if code == 0 else 'failed', exit_code=code,
               ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               elapsed_seconds=time.monotonic()-start, log=str(log_path))
record_path.write_text(json.dumps(receipt, indent=2)+'\n')
print(f"END {name} status={receipt['status']} elapsed={receipt['elapsed_seconds']:.2f}s", flush=True)
print(''.join(log_path.read_text(errors='replace').splitlines(keepends=True)[-22:]), flush=True)
raise SystemExit(code)
