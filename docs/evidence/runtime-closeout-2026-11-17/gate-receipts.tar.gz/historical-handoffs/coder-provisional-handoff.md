# Batch all-open-runtime (B)

## Scope and identity

- State / owner: coder source frozen at the current head; combined gate freeze awaits parent settings and final integrated review.
- User objective: finish all open issues and merge qualified work into main; no timebox.
- Issues: #1290 operation-owned failures/terminal retirement; #1279 effect admission, policy and retained-resource obligations. #1271 broader qualification and #1188 native/background unsupported API remain separate.
- Canonical contracts: docs/sql-replayable-transaction-contract.md, docs/transaction-authority-midge-contract.md, docs/transaction-owner-mutation-inventory.md, docs/pgwire-transaction-contract.md, docs/session-object-ownership.md, docs/pgwire-blocking-cleanup.md.
- Baseline: 0f5312d098a868a4f9c556e4050d7a593587568a (Batch A tooling/fixture parent).
- Coder branch/worktree: codex/all-open-runtime-closeout-20261116, /private/tmp/cassie-all-open-runtime-closeout-20261116.
- Current head / tree: 9ee699398bfb0b99ab338420169d68ced06aa52d / e000383a4f919ca1dd33461213a157ae787368d8.
- Ownership: root mutation/effect/failure lineage, owning tests/docs, wire completion and resource plumbing; parent supplied disjoint portal/SessionObjects/TRUNCATE/cleanup increments. Parent owns actual-root shared-setting repair and can hand it separately to assembler for combined integration.
- Assembler owns all compilation, shared gate/inventory/registration changes and GitHub publication.
- Boundaries: published cntryl-midge0.5.2 only; no engine edits, second storage layer, CI/release/version configuration changes.
- Live issue evidence re-read with gh issue view1290/1279 --repo cntryl/cassie --json title,body,state on current session. Both remain OPEN, acceptance/gates not claimed complete.

## Coder handoff

- Ordered immutable range:
```
0ad9869e Bug: Classify setval without currval assignment as a strict sequence effect
e9a51b89 Bug: Admit sequence effects under the captured transaction owner before native submission
f36791aa Bug: Refuse detached sequence effects without their root operation lineage
4759b5f7 Bug: Carry admitted transaction failure authority through outer wire completion
f4017e44 Bug: Fence terminal cleanup and mutation admission with the captured transaction owner
d515c54c Bug: Validate transaction ownership at root mutation and setting boundaries
9daff97b Bug: Publish and retire wire portals under their transaction owner
26d1c799 Bug: Retain the bound portal owner for admitted Execute validation
4fc7d87f Bug: Pin detached identity restart ownership across transaction replacement
5b398b72 Bug: Give statement forks owned schema contexts and retained memory guards
731e21b5 Bug: Fence shared session object mutations with the actual operation owner
7fd6b8c7 Bug: Deny sealed shared object mutation to detached commit-thread forks
f4fd01f2 Bug: Preserve held cursor publication after an owned implicit retirement
ad403a0a Bug: Admit portal execution against its bound transaction owner
ce6abece Bug: Publish protocol registry state only for the admitted frame owner
7c3f7685 Bug: Detach exact wire ID cleanup from the rejected frame authority
71ce4e4f Bug: Fence sequence history publication after native effect completion
be2b8187 Test: Preserve portal ownership across actual cleanup and savepoint boundaries
999ce0ed Documentation/readiness: Record current operation authority repairs and pending proof
a7fef94f Bug: Retain deferred schema cleanup in its started blocking worker
e9d25826 Bug: Retain listener admission through actual blocking worker retirement
4e237474 Refactor: Name the registry worker context consistently across test builds
9ee69939 Test: Replace wire transactions through an independent root clone
```
- Changed paths (93):
```
docs/pgwire-blocking-cleanup.md
docs/pgwire-transaction-contract.md
docs/session-object-ownership.md
docs/sql-replayable-transaction-contract.md
docs/transaction-authority-midge-contract.md
docs/transaction-owner-mutation-inventory.md
src/app/bulk_ingest.rs
src/app/defaults.rs
src/app/mod.rs
src/app/projection_sql_durability_tests.rs
src/app/query.rs
src/app/query_bound.rs
src/app/query_ctas.rs
src/app/query_failure_converted_tests.rs
src/app/query_failure_savepoint_tests.rs
src/app/query_lifecycle.rs
src/app/query_lifecycle/authority_test_hooks.rs
src/app/query_operation.rs
src/app/query_prepared.rs
src/app/query_prepared/authority_tests.rs
src/app/query_transactions.rs
src/app/referential.rs
src/app/roles.rs
src/app/session.rs
src/app/session/catalog_overlay.rs
src/app/session/copy_owner_tests.rs
src/app/session/failure_authority.rs
src/app/session/projection_write.rs
src/app/session/savepoint_fork_epoch_tests.rs
src/app/session/savepoints.rs
src/app/session/sequence_effect.rs
src/app/session/sequence_effect_tests.rs
src/app/session/setting_control.rs
src/app/session/sql_objects.rs
src/app/session/statement_batch.rs
src/app/session/transaction_control.rs
src/app/session/transaction_snapshot.rs
src/app/session/truncate_owner_tests.rs
src/app/session/wire_failure.rs
src/app/session/wire_failure_tests.rs
src/app/session_objects.rs
src/app/session_objects/cursors.rs
src/app/session_objects/discard.rs
src/app/session_objects/ownership_tests.rs
src/app/session_objects/prepared.rs
src/app/session_schema.rs
src/app/session_schema/owned_context.rs
src/app/session_schema/tests.rs
src/app/session_sequences.rs
src/app/session_sequences/discard_restart_tests.rs
src/app/session_sequences/history_owner_tests.rs
src/app/statement_mutation.rs
src/app/storage_recovery.rs
src/executor/execution/dml_command.rs
src/executor/execution/dml_truncate.rs
src/executor/execution/dml_upsert_wait.rs
src/executor/execution/modifying_ctes.rs
src/executor/execution/session_command.rs
src/executor/filter/sequence_functions.rs
src/midge/adapter/schema_ops/copy_identity_tests.rs
src/pgwire/connection.rs
src/pgwire/connection/blocking.rs
src/pgwire/connection/blocking/cleanup_test_hooks.rs
src/pgwire/connection/blocking/tests.rs
src/pgwire/connection/copy.rs
src/pgwire/connection/copy/binding_authority_accounting_tests.rs
src/pgwire/connection/copy/diagnostic_tests.rs
src/pgwire/connection/copy/diagnostics.rs
src/pgwire/connection/copy/execute.rs
src/pgwire/connection/copy/outer_failure_tests.rs
src/pgwire/connection/extended.rs
src/pgwire/connection/extended/bind.rs
src/pgwire/connection/extended/bind/ownership_tests.rs
src/pgwire/connection/extended/execute.rs
src/pgwire/connection/extended/frontend.rs
src/pgwire/connection/extended/parse.rs
src/pgwire/connection/extended/portal_streaming.rs
src/pgwire/connection/extended/prepared_state.rs
src/pgwire/connection/extended/registry_publication_tests.rs
src/pgwire/connection/extended/transaction_boundary.rs
src/pgwire/connection/idle_portal_snapshot_tests.rs
src/pgwire/connection/simple_execution.rs
src/pgwire/connection/state.rs
src/pgwire/connection/state/portal_owners.rs
src/pgwire/connection/state/portal_owners/tests.rs
src/pgwire/connection/state/portal_ownership_tests.rs
src/pgwire/connection/transactions.rs
src/pgwire/connection/wire_failure_boundary_tests.rs
src/pgwire/connection/wire_failure_test_hooks.rs
src/pgwire/connection/worker_lease.rs
src/pgwire/connection/worker_lease/network_tests.rs
src/pgwire/connection/worker_lease/tests.rs
src/pgwire/server.rs
```
- Authored regressions are NOT RUN; no observed RED is claimed. No Cargo build/test/Clippy/bench/qualification was run by coder.
- Actual validation: direct rustfmt --edition2021 --config skip_children=true on owned touched Rust files and git diff --check passed at each increment. These do not constitute ordered format/gate qualification.
- Regression ordering: initial sequential setval, sequence admission, missing-lineage, helper ownership, terminal COMMIT/resource guards, explicit portal provenance, registry final guard, sequence history, cleanup and connection resource controls were authored before their corresponding implementations. Actual simple/extended/COPY outer-wrapper tests were authored AFTER initial wrapper edits. Dedicated RR getter alias control was authored AFTER the RR getter guards. Additional positive portal/SessionObjects controls followed their initial implementation. Preserve these distinctions; no reconstructed RED.
- Last test-only correction:9ee699 uses a truly independent unscoped root clone for three stale outer-wrapper actor callbacks, asserting the original carrier remains unchanged. Their earlier scoped clone incorrectly adopted B through its own authorized retirement/BEGIN. Survivor assertions are unchanged.
- Important source-found correction: ce6 used with_operation_failure_authority(None) as though it cleared lineage; that API intentionally preserves existing lineage. 7c3 adds an explicit unscoped clone only for exact-wire-ID cleanup and its tests; original helper semantics unchanged.

### Acceptance and executable probe map

| Obligation | Source / required controls | Status |
| --- | --- | --- |
| #1290 atomic owned current failure, replaced B usable | query_lifecycle/query_prepared, FailureAuthority/wire_failure, converted/prepared authority tests, actual simple/extended/COPY outer error tests | authored/not run |
| Own BEGIN/implicit promotion/savepoint adoption, recovery/error precedence | sequence_effect_tests; wire_failure_tests old-savepoint/rollback/own-start/quarantine; existing query_* authority_capture/tests | authored/not run |
| No mutation before generic saturated capture; preserve captured origin | wire_failure_boundary_tests own-origin saturation, capturedA/B saturation and uncaptured root-contended saturation+outer fail; existing cancellation/recovery precedence | authored/not run |
| All root mutation and mutable alias admission | transaction-owner-mutation-inventory.md; wire_failure_tests old INSERT/settings/staging/catalog/RR alias; parent shared settings pending | authored/not run; shared settings integration pending |
| Native sequence strictness before effect / false-setval | sequence_effect_tests; replay SQL policy tests including deferred-conflict retry, no-effect buffered/unknown controls | authored/not run; previous main evidence not current qualification |
| Sequence post-native history cannot overwrite B | session_sequences/history_owner_tests actual nextval/setval/default A→B reset/other-sequence-history + current positive; native/global catalog publication before historyErr | authored/not run |
| Actual TRUNCATE restart captured A cannot affect B | session/truncate_owner_tests B COMMIT/ROLLBACK, native+published cursor/rows/objectidentity, observer nextval | authored/not run |
| Shared schema context/descriptor ownership and retained memory | session_schema/owned_context + tests; actual SQL attachment/fake-private-fork controls; query tracker/lastArc tests | authored/not run |
| Shared SessionObjects and scope/retirement preservation | session_objects/ownership_tests actual PREPARE/DECLARE/FETCH/MOVE/CLOSE/DEALLOCATE/DISCARD/protocol; sealed fork/root and WITH HOLD own-retirement controls | authored/not run |
| Wire portal ownership and preparation adoption | state/portal_ownership_tests, extended/bind/ownership_tests, actual wire idle→implicit/explicit BEGIN, savepoint epoch, oldA portal→B healthy, empty Query handoff, retained legacy snapshot tests | authored/not run |
| Parse/Close registry and final map publication | extended/registry_publication_tests actual named/unnamed afterregistry A→B, exact newer ID survivor, statement+portal Close B survival, current success | authored/not run |
| COPY inline and shared owner accounting/lifetime | copy/binding_authority_accounting_tests actual B−S/B charges, earlier force/error precedence, same tracker, ambient controls, cancellation, last outer/last worker clone | authored/not run |
| Async deferred cleanup | blocking/tests operation success/error/panic/recovery skip/waiter abort/neverstarted controls, same started worker through cleanup | authored/not run |
| Retained worker admission lifetime | worker_lease/tests op abort/cleanup-last/queued cancel; actual network maxConnections1/queryWorkers1 COPY WHERE +disconnect/rejection53300/listenershutdown/final release | authored/not run |

## Review handoff

- Reviewer: /root/review; exact increments through9ee69939 accepted for bounded integration pending executable probes; final combined review remains.
- Receipts: /private/tmp/cassie-review-all-20261116/target/assembly-line/all-open-review. Named prefixes include explicit-lineage, effect-e9a51b89, stale-root-contract, schema-5b398b72, shared-object-root-guard, wire-ad403a0a, parse-publication-contract, captured-admission-contract, increments, worker-e9d25826.
- Jev probabilities >=.30 remain execution obligations, not source-only passing dispositions: sequence lineage/strict ordering; TRUNCATE hook/oracle; saturation .37 and RR .49; sequence history .36; legacy portal .35; resource census .43 and network .44. All exact authored controls must run at the coherent gate.
- Selected contracts recorded before dependent code: pre-admission uncaptured no mutation; captured owner survives later saturation; UUID/epoch/generation root mutation admission25000 (current failed25P02); native sequence strict marker before I/O; postnative history seq-values→actual-root; fork-local schema context; actual-root shared object guard; exact own-retirement shared-state receipt only; expected portal lifetime and own-any-BEGIN prep adoption; owned worker cleanup; explicit resource-tasklocal lease capture.

## Assembly and integrated review

- Inputs are the ordered range above, plus parent actual-root shared-settings increment pending.
- This current head is NOT final gate-ready. Obtain exact final combined source/Jev review after all source repairs and conflict resolutions, then freeze.
- Changed source invalidates affected prior review identity. No independent PR/push/merge by coder.

## Qualification and publication

| Check | Source identity | Result |
| --- | --- | --- |
| Build | final B pending | not run |
| Complete locked tests | final B pending | not run |
| Full workspace all-target/all-feature strict Clippy | final B pending | not run |
| Full format check | final B pending | not run |
| Touched-test policy/inventory | final B pending | not run |
| Final-head hosted checks | final B pending | not run |

- Assembler owns build → complete locked tests → strict Clippy → format → touched test validation and full affected controls.
- Keep original native policy/deferred conflict/no-effect buffered/OutcomeUnknown, COPY, CTAS/CALL/modifying CTE/EXPLAIN/UDF, savepoint and pool controls in full gate. Do not substitute helper probes for actual routes.
- Per-listener resource limit is intentionally scoped: every admitted connection/started worker retains its EXISTING listener slot through cleanup. Direct external run_connection without listener scope and arbitrary multiple listener instances do not establish a runtime-global bound. No native cancellation/quiescence/time bound claimed.
- #1279 requires persistence/replay/comparison/cloud evidence in addition to runtime source. Use actual assembler A/B evidence; no issue closure based on this handoff alone.
- #1188 remains blocked on published native/background API and upstream1045; #1271 broader100k/loss/cloud qualification remains independent.
