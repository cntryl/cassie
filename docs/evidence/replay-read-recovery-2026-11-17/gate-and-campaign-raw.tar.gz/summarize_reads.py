import json,pathlib,hashlib,statistics,math,csv,sys
R=pathlib.Path('target/assembly-line/replay-qualification').resolve();suffix=sys.argv[1] if len(sys.argv)>1 else '';p=R/('read-campaign'+suffix+'.jsonl');records=[];nonjson=[]
for line in p.read_text().splitlines():
 try:records.append(json.loads(line))
 except json.JSONDecodeError:nonjson.append(line)
receipt=json.loads((R/('read-campaign'+suffix+'.json')).read_text());profiles=[x for x in records if x.get('kind')=='read_profile'];samples=[x for x in records if x.get('kind')=='read_sample'];warm=[x for x in records if x.get('kind')=='untimed_warmup']
summary={'source':receipt['source'],'status':receipt['status'],'actual_profile_records':len(profiles),'actual_passed_profiles':sum(x['status']=='passed' for x in profiles),'actual_timed_samples':len(samples),'actual_warmup_samples':len(warm),'command_elapsed_seconds':receipt['elapsed_seconds'],'raw_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'profiles':[],'limits':'Embedded SQL execute/materialization only; copy/hash/startup/correctness outside timer. Localhost finite diagnostics, no speedup/provider/power-loss/native-quiescence claim.'}
rows=[]
for x in profiles:
 key=(x['mode'],x['shape']);ss=[s for s in samples if (s['mode'],s['shape'])==key];ww=[s for s in warm if (s['mode'],s['shape'])==key]
 item={'mode':key[0],'shape':key[1],'status':x['status'],'timed_samples':len(ss),'warmup_samples':len(ww),'error':x['error'],'original_fingerprint_verified_after_copy':x['original_fingerprint_verified_after_copy'],'original_fingerprint_verified_after_reader_drop':x['original_fingerprint_verified_after_reader_drop'],'distributions':{}}
 if x['status']=='passed':
  assert len(ss)==51 and len(ww)==17 and ss==x['result']['samples']
  assert x['original_fingerprint_verified_after_copy'] and x['original_fingerprint_verified_after_reader_drop']
  assert all(s['error'] is None for s in ss+ww)
  for family,n in [('equality',48),('count',3)]:
   values=sorted(int(s['elapsed_ns']) for s in ss if s['family']==family);assert len(values)==n
   median=statistics.median(values);median_s=str(int(median)) if float(median).is_integer() else str(median)
   p95=values[math.ceil(n*.95)-1];reported=x['result'][family]
   assert reported['n']==n and reported['p50_ns']==median_s and reported['p95_ns']==str(p95)
   item['distributions'][family]={'n':n,'p50_ns':median_s,'p95_ns':str(p95),'min_ns':str(values[0]),'max_ns':str(values[-1])}
  for round in [0,1,2,3]:
   group=[s for s in ss+ww if s['round']==round];assert len(group)==17
   eq=[s for s in group if s['family']=='equality'];count=[s for s in group if s['family']=='count'];assert len(eq)==16 and {s['bucket'] for s in eq}==set(range(16))
   assert all(s['rows']==6250 for s in eq) and count[0]['rows']==1 and count[0]['attestation']['round_unique_ids']==100000
   for s in eq:
    a=s['attestation'];assert (a['index_ops']>0 and a['collection_scans']==0) if key[1]=='indexed' else (a['index_ops']==0 and a['collection_scans']>0)
 summary['profiles'].append(item)
 for s in ss+ww:rows.append({k:s[k] for k in ['kind','mode','shape','round','family','bucket','elapsed_ns','rows']})
if receipt['status']=='passed':assert len(profiles)==8 and summary['actual_passed_profiles']==8 and len(samples)==408 and len(warm)==136 and len({(x['mode'],x['shape']) for x in profiles})==8
(R/('read-summary'+suffix+'.json')).write_text(json.dumps(summary,indent=2)+'\n')
with (R/('read-samples'+suffix+'.csv')).open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['kind','mode','shape','round','family','bucket','elapsed_ns','rows'],lineterminator='\n');w.writeheader();w.writerows(rows)
print(json.dumps({k:v for k,v in summary.items() if k!='profiles'}));print('non-JSON diagnostic lines:',len(nonjson))
