# C cloud-cache-loss handoff

## Reviewed-lead repair snapshot

- Current head `2cebd09a237bfb46ab15db295ad8f91a5adda5d8`,
  tree `ea95a37ff95cf77925beb0d1903f2d7845ef7edc`, same base42f863e4.
- Added ordered65d87e31 contract,2e71f4e5 extra-owner probe,897a20e6
  exact native Busy probe,2cebd09a consuming owned-close fixture helper.
- Nine new tests now (eight non-Unix), all unrun. Add two close negatives to
  original seven. Exact canonical Busy result is retained without Cassie string
  conversion; extra Midge Arc is separately refused with an ownership prefix.
- Baseline retains one Midge Arc, drops all session/Cassie owners, then asserts
  successful public mutable Engine::shutdown(30s) before spawning the child.
- Corrected source fact: adapter Drop already attempts native shutdown(5s) but
  only warns on failure; falling through after failure permits detached engine
  cleanup. New helper makes actual successful owned handoff an assertion.
- Native Busy negative holds a real memory-mode native transaction with the
  Midge Arc otherwise exclusive; asserts exact Busy (not ownership-prefix),
  then drops the transaction. No native result replacement/internal hook.
- This helper is cfg(test), not global/background quiescence or1188 closure.

- Base: `42f863e4`; head `5840c2781f7042f0ed4c445eceb88d1bc1e7300b`;
  tree `a1232db093220cd087b6d35cba25f7674278b483`.
- Ordered commits: `1441d8dd` contract; `03ec8fcc` four recovery declarations;
  `4d8e7615` three ownership controls; `5840c278` fixture implementation.
- Worktree: `/private/tmp/cassie-cloud-cache-loss-20261117`.
- No Cargo run, observed RED, runtime pass, or qualification is claimed.
  Direct rustfmt and `git diff --check` passed.
- Exclusive paths: new `replay_cloud_cache_loss.rs` and owning doc; minimal
  cfg-test TTL constructor in `core.rs`; generic owned-directory/child-marker
  reuse in `replay_process_crash.rs`, retaining all original test assertions.
- Assembler-owned registration still needed in statement_read/tests.rs:
  `#[path = "tests/replay_cloud_cache_loss.rs"] mod replay_cloud_cache_loss;`.
- All new code is test-only. Existing cloud constructor keeps TTL300;
  new helper uses canonical public builder, campaign passes TTL60/default skew30.
- Four selected cases: API strict/replayable; SQL explicit strict/replayable.
  Baseline position1 uses cloud strict + clean shutdown. Child background
  configuration submits actual position2 transaction, emits ACK after return,
  parent kills/reaps before wiping cache. No synthetic storage failure.
- Strict requires recovered2; async accepts complete1/2. Before replay, exact
  rows/PKs, checkpoint, direct scalar index hits and API ledger agree. API retry
  checks applied/duplicate counts; SQL skips by recovered checkpoint, no ledger
  claim. Both reach2 and repeat without duplicate rows/events.
- Ownership helper binds exact canonical owned cache path and token, refuses
  symlinks/foreign/unowned roots, preflights nested paths before deletion,
  hashes every remote relative file and retains directory identities, wipes
  only non-cloud_store entries, compares full remote snapshot BEFORE reopen.
  The retained-source sentinel is outside cache and separately compared.
- Lease recovery retries only known `Writer lease held: ` storage errors with
  120s hang guard; no lease edits. Existing generic child timeout remains30s.
- Seven new tests (six on non-Unix): four recovery names in source plus
  `should_refuse_foreign_and_unowned_cache_roots_before_deletion`,
  `should_refuse_symlinked_cache_before_deletion` (Unix),
  `should_preserve_remote_hashes_and_retained_source_when_wiping_owned_cache`.
- Actual execution command after registration:
  `cargo test --locked --lib midge::adapter::statement_read::tests::replay_cloud_cache_loss:: -- --nocapture`.
  Full ordered gate must execute these by default; retain emitted actual
  recovered_position per profile. Source review should also check existing
  process_crash controls since their harness is shared.
- No power-loss, real-provider, actual async-loss occurrence, global WAL
  quiescence or bounded-loss guarantee. Broader #1271/#1188 remain open.
