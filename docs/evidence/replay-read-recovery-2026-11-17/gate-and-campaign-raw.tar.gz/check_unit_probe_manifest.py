from pathlib import Path
import importlib.util,hashlib,json,subprocess
root=Path.cwd(); manifest=json.loads((root/'docs/testing/replay-qualification-unit-probes-2026-11-17.json').read_text())
spec=importlib.util.spec_from_file_location('cassie_inventory',root/'tools/test_inventory.py'); module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
count=0
for file in manifest['files']:
    parsed=module.rust_declarations(root/file['file'])
    assert hashlib.sha256(parsed['data']).hexdigest()==file['sha256'],file['file']
    assert len(parsed['data'].splitlines())==file['lines']
    assert len(parsed['tests'])==len(file['test_declarations'])
    for actual,record in zip(parsed['tests'],file['test_declarations']):
        for key in ['name','inline_modules','line','end_line','attributes']:assert actual[key]==record[key],(file['file'],key,record['name'])
        assert hashlib.sha256(actual['body'].encode()).hexdigest()==record['body_sha256']
        count+=1
assert count==manifest['declaration_count']
assert len(manifest['files'])==manifest['file_count']
print(json.dumps({'status':'passed','file_count':len(manifest['files']),'declarations':count,'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'static hashes, declarations, locations, attributes and body hashes; not executable registration proof'}))
