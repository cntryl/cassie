import pathlib,json,hashlib,subprocess,os
R=pathlib.Path('target/assembly-line/replay-qualification').resolve();I=R/'read-inputs';old=I/'read-manifest.json';new=I/'read-manifest-2.json';assert not new.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads(old.read_text());source={'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()};assert source['commit']=='a5fd91760e8cab27dad04e2d60b019b446304d4a'
exe=pathlib.Path('target/debug/build/cassie/e6e852e886807813/out/tier3_replay_durability-e6e852e886807813').resolve();records=[]
for profile in manifest['profiles']:
 raw=json.loads(pathlib.Path(profile['result_path']).read_text());env=os.environ.copy();env['CASSIE_REPLAY_BENCH_SOURCE_FINGERPRINT']=raw['storage_path'];p=subprocess.run([str(exe)],env=env,capture_output=True,text=True,timeout=120);assert p.returncode==0
 fp=json.loads(p.stdout);assert fp['fingerprint']==profile['source_fingerprint'];records.append(fp)
manifest['reader']=source;new.write_text(json.dumps(manifest,indent=2)+'\n')
copy=I/'reader-cargo-fingerprint-2';copy.mkdir();fps=[]
for p in pathlib.Path('target/debug/build/cassie/e6e852e886807813/fingerprint').iterdir():
 if 'tier3_replay_durability' not in p.name:continue
 dest=copy/p.name;dest.write_bytes(p.read_bytes());fps.append({'path':str(p.resolve()),'preserved_copy':str(dest),'sha256':sha(p),'bytes':p.stat().st_size})
identity={'source':source,'build_receipt':str(R/'read-bench-compile-2.json'),'executable':str(exe),'executable_sha256':sha(exe),'bytes':exe.stat().st_size,'fingerprint_files':fps,'manifest_sha256':sha(new),'prior_manifest_sha256':sha(old),'only_manifest_change':'reader source identity; all eight original producer/closure/result/log/fingerprint records unchanged','source_fingerprint_rechecks':records,'scope':'Trusted local Cargo build provenance, not remote cryptographic attestation.'}
(I/'reader-build-identity-2.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps({k:identity[k] for k in ['source','executable_sha256','manifest_sha256','prior_manifest_sha256']}))
