import pathlib,json,tarfile,hashlib,gzip,io
R=pathlib.Path('target/assembly-line/replay-qualification').resolve();out=R/'durable-export';out.mkdir(exist_ok=True)
# Explicit directory/depth allowlist excludes datasets, executable artifacts, and source-state requests.
paths=[]
for p in R.iterdir():
 if p.is_file() and p.suffix in ['.json','.log','.py','.md','.csv','.jsonl','.txt']:paths.append(p)
I=R/'read-inputs'
for p in I.iterdir():
 if p.is_file() and p.suffix in ['.json','.log']:paths.append(p)
for name in ['replacement-api','retained-a-producer','reader-cargo-fingerprint','reader-cargo-fingerprint-2','index-metadata-diagnostic']:
 d=I/name if name!='index-metadata-diagnostic' else R/name
 if not d.exists():continue
 for p in d.iterdir():
  if p.is_file() and (p.suffix in ['.json','.log','.rs','.md'] or (name.startswith('reader-cargo-fingerprint') and not p.suffix)):paths.append(p)
assert all(p.stat().st_size<10_000_000 for p in paths)
manifest=[];archive=out/'gate-and-campaign-raw.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
 for p in sorted(set(paths)):
  data=p.read_bytes();arc=str(p.relative_to(R));info=tarfile.TarInfo(arc);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data));manifest.append({'path':arc,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'archive-manifest.json').write_text(json.dumps({'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'files':manifest,'exclusions':'All dataset directories, executables/native artifacts, credentials/auth headers and Jev source-state request bodies are excluded. Exact artifact hashes/provenance are retained as receipts.'},indent=2)+'\n')
print(archive,len(manifest),archive.stat().st_size)
