import pathlib,subprocess,os,json,hashlib,datetime,time,signal,sys
R=pathlib.Path('target/assembly-line/replay-qualification').resolve();suffix=sys.argv[1] if len(sys.argv)>1 else '';manifest=R/('read-inputs/read-manifest'+suffix+'.json');out=R/('read-campaign'+suffix+'.jsonl');receipt=R/('read-campaign'+suffix+'.json')
assert not out.exists() and not receipt.exists()
exe=pathlib.Path('target/debug/build/cassie/e6e852e886807813/out/tier3_replay_durability-e6e852e886807813').resolve()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
state={'source':json.loads(manifest.read_text())['reader'],'command':[str(exe)],'environment_selectors':{'CASSIE_REPLAY_BENCH_READ_MANIFEST':str(manifest)},'manifest_sha256':sha(manifest),'executable_sha256':sha(exe),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','process_hang_guard_seconds':1800}
def save():receipt.write_text(json.dumps(state,indent=2)+'\n')
save();env=os.environ.copy();env.update(state['environment_selectors']);start=time.monotonic()
with out.open('wb') as stream:
 p=subprocess.Popen([str(exe)],env=env,stdout=stream,stderr=stream,start_new_session=True)
 try:
  code=p.wait(timeout=1800);state.update(exit_code=code,status='passed' if code==0 else 'failed')
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGKILL);p.wait();state.update(exit_code=p.returncode,status='failed_timeout')
state.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-start,log_path=str(out),log_sha256=sha(out));save()
print(json.dumps(state))
raise SystemExit(0 if state['status']=='passed' else 1)
