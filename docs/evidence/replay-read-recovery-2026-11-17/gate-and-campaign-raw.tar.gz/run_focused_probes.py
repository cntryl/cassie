from pathlib import Path
import json,subprocess,datetime,time,re,sys,os
root=Path.cwd(); out=root/'target/assembly-line/replay-qualification'; prefix=sys.argv[1] if len(sys.argv)>1 else 'focused'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],text=True)
modules=[('cloud-cache-loss',['-p','cassie','--lib'],'midge::adapter::statement_read::tests::replay_cloud_cache_loss::',9),('read-ownership',['-p','cassie-integration-tests','--test','bench_diagnostics'],'replay_read_ownership::',9),('legacy-process',['-p','cassie','--lib'],'midge::adapter::statement_read::tests::replay_process_crash::',5)]
record={'head':head,'tree':tree,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','modules':[]};receipt=out/(prefix+'-probes.json');receipt.write_text(json.dumps(record,indent=2)+'\n')
for name,target,selector,expected in modules:
    command=['cargo','test','--locked',*target,selector,'--','--nocapture'];log=out/(prefix+'-'+name+'.log');item={'name':name,'command':command,'selector':selector,'expected_cases':expected,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running'};record['modules'].append(item);receipt.write_text(json.dumps(record,indent=2)+'\n');print('START',name,'expected',expected,flush=True);start=time.monotonic()
    with log.open('w') as stream:code=subprocess.call(command,stdout=stream,stderr=subprocess.STDOUT,env=os.environ.copy())
    text=log.read_text(errors='replace');matches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);actual=sum(int(x[1]) for x in matches);item.update(exit_code=code,actual_passed=actual,elapsed_seconds=time.monotonic()-start,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),log=str(log),status='passed' if code==0 and actual==expected and all(x[0]=='ok' and int(x[2])==0 and int(x[3])==0 for x in matches) else 'failed')
    if name=='cloud-cache-loss':
        observations=[{'profile':p,'recovered_position':int(v),'retained_remote_entries':int(n)} for p,v,n in re.findall(r'CASSIE_CLOUD_CACHE_LOSS\|([^|\s]+)\|recovered_position=(\d+)\|retained_remote_entries=(\d+)',text)]
        item['recovery_observations']=observations
        valid=len(observations)==4 and {x['profile'] for x in observations}=={'api_strict','api_replayable','sql_strict','sql_replayable'} and all(x['recovered_position'] in ([2] if x['profile'].endswith('_strict') else [1,2]) for x in observations)
        if item['status']=='passed' and not valid:item.update(status='failed_validation',validation_error='Missing/duplicate or invalid actual recovery observations')
    if name=='read-ownership' and item['status']=='passed' and 'should_encode_sha256_digest_bytes_in_canonical_lowercase_hex ... ok' not in text:item.update(status='failed_validation',validation_error='Canonical SHA256 oracle success not observed')
    receipt.write_text(json.dumps(record,indent=2)+'\n');print('END',name,item['status'],'actual',actual,flush=True)
    if item['status']!='passed':
        record.update(status=item['status'],ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());receipt.write_text(json.dumps(record,indent=2)+'\n');print(text[-18000:],flush=True);raise SystemExit(code or 1)
record.update(status='passed',actual_passed=sum(x['actual_passed'] for x in record['modules']),ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());receipt.write_text(json.dumps(record,indent=2)+'\n');print('FOCUSED',record['actual_passed'],'passed',flush=True)
