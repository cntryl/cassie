import pathlib,json,hashlib,subprocess,time,datetime
R=pathlib.Path('target/assembly-line/replay-qualification').resolve();O=R/'index-metadata-diagnostic';O.mkdir(exist_ok=True)
source=pathlib.Path('/private/tmp/cassie-read-index-metadata-diagnostic-20261117/target/assembly-line/index-metadata-diagnostic/probe.rs')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source)=='903bb9b8199429a6f1535e38eff1297f6a4025845a19fbbe539e986627f9c5e5'
assert json.loads((R/'read-campaign.json').read_text())['status']!='running'
root=pathlib.Path('target/debug/build').resolve();bench=root/'cassie/e6e852e886807813/fingerprint/test-bench-tier3_replay_durability.json';bj=json.loads(bench.read_text());index={}
for f in root.glob('*/*/fingerprint/lib-*'):
 if f.suffix or f.name.endswith('.json'):continue
 try:value=int.from_bytes(bytes.fromhex(f.read_text().strip()),'little')
 except (ValueError,UnicodeDecodeError):continue
 index.setdefault((f.name[4:],value),[]).append(f)
required={};dirs=set();receipts=[]
def resolve(name,value):
 key=(name,value)
 if key in required:return required[key]
 matches=index.get(key,[])
 if not matches:matches=[f for (actual,token),values in index.items() if token==value for f in values]
 assert len(matches)==1,(key,matches)
 f=matches[0];meta=json.loads(f.with_suffix('.json').read_text());out=f.parent.parent/'out';dirs.add(out);required[key]=out
 receipts.append({'crate':name,'dependency_token':value,'fingerprint':str(f),'fingerprint_sha256':sha(f),'metadata_sha256':sha(f.with_suffix('.json')),'artifacts':[{'path':str(p),'sha256':sha(p)} for p in out.glob('lib'+name+'-*') if p.suffix in ['.rlib','.dylib']]})
 for d in meta['deps']:
  if any(token==d[3] for actual,token in index):resolve(d[1],d[3])
 return out
extern=[]
for d in bj['deps']:
 if d[1] in ['cassie','serde','serde_json','sha2','uuid']:
  out=resolve(d[1],d[3]);libs=list(out.glob('lib'+d[1]+'-*.rlib'));assert len(libs)==1;extern.extend(['--extern',d[1]+'='+str(libs[0])])
command=['rustc','--edition=2021','--crate-name','cassie_index_metadata_probe',str(source)]
for d in sorted(dirs):command.extend(['-L','dependency='+str(d)])
command+=extern+['-o',str(O/'probe')]
state={'source_head':'66916fee39adc277b27540366200bfa013113110','source_tree':'3308fca2f53958e28b37b6a66d7751b376a5832e','probe_sha256':sha(source),'command':command,'toolchain':subprocess.check_output(['rustc','-vV'],text=True),'resolved_artifacts':receipts,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running'}
p=O/'compile-2.json';p.write_text(json.dumps(state,indent=2)+'\n');start=time.monotonic()
with (O/'compile-2.log').open('wb') as log:result=subprocess.run(command,stdout=log,stderr=log,timeout=180)
state.update(exit_code=result.returncode,status='passed' if result.returncode==0 else 'failed',elapsed_seconds=time.monotonic()-start,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
if result.returncode==0:state['binary_sha256']=sha(O/'probe')
p.write_text(json.dumps(state,indent=2)+'\n');print(json.dumps({k:v for k,v in state.items() if k not in ['command','resolved_artifacts','toolchain']}));raise SystemExit(result.returncode)
