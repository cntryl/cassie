# Final Batch B transaction-clock repair

## Scope and identity

- Parent-assigned original #1290 shared-state ownership fence; no Cargo execution.
- Base:da05f1bc12624027b0c115b896e668e0f1c9121c (source-reviewed actual COPY policy controls).
- Head:cd373e8623a7af9d5bda6ee0c11ee0b61d6cd77b.
- Tree:ac3ccc102ff527c0f6d8865bd6cfd5f8f6e6bb53.
- Worktree/branch:/private/tmp/cassie-copy-native-policy-probe-20261116, codex/copy-native-policy-probe-20261116.
- Files: temporal_context.rs, temporal_context/tests.rs, statement_text.rs, narrow helper in session/sql_objects.rs and owning mutation inventory doc.
- Selected contract recorded before dependent code: actual root status/generation and shared clock publication under one root→clock guard. Exact lifecycle-root own-retirement Idle receipt permits statement-start only, no shared clock read/write; no fork/ABA/unrelated receipt. Existing actual-root authority checks remain.

## Coder handoff

- Cherry-pick cd373e86 only after da05.
- Focused regressions authored FIRST; all are authored/not run, no observed RED or green.
- Exact selector: cargo test --locked --lib app::session::temporal_context::tests:: -- --nocapture
- Controls:
  - should_refuse_an_old_root_or_fork_clock_without_resetting_b_now (two actual SQL root/fork schedules paused before root guard, independent A rollback/B begin/now init, stale25000 plus B clock/generation/now stability)
  - should_install_the_first_current_clock_under_root_then_clock_locks (in-guard no-wait observer verifies actual root and clock held; current fork lineage positive)
  - should_keep_idle_statement_start_separate_from_the_shared_transaction_clock
  - should_allow_only_the_own_retired_root_to_install_an_idle_statement_clock (actual own COMMIT positive, same shared receipt fork negative, independent B ABA negative)
  - should_not_adopt_another_actors_commit_as_an_idle_clock_receipt
  - should_preserve_now_through_an_actual_nested_procedure_call
- Private temporal installation is fallible; with_statement_text propagates it with ?. This is the only production caller, so existing Result callers need no API rewrite.
- Existing query-slot/capture/error precedence preserved: no new early root capture or I/O. Statement-text memory preflight remains before temporal installation.
- Actual validation: direct rustfmt on owned files and git diff --check passed. No build/test/Clippy/bench/fullformat/test policy run by coder.

## Review handoff

- Exact base/head/tree sent to /root/review. Receipts transaction-clock-contract-* (.98 actualRoot guard, .81 actual sharedRoot schedule) and clock-idle-receipt-* (exact own idle no-write1.0, probe .61).
- Exact affected-source/Jev accepted integrate_pending_execution .91; owner gap .08/Idle .05; probe .32 requires supplied six named tests/seven runtime cases at coherent gate. No additional new probe requested.

## Assembly and integrated review

- New focused test module is local under temporal_context.rs; assembler owns inventory metadata update and final integrated source review.
- Combine after da05 and standing Batch B inputs. Any further source change invalidates affected review identity.

## Qualification and publication

- Build, locked complete tests, all-target/all-feature strict Clippy, full format/test policy/inventory, hosted checks: NOT RUN for this increment.
- Parent/assembler own complete ordered gate, PR, final-head checks and merge. No issue closure or qualification claim by coder.
