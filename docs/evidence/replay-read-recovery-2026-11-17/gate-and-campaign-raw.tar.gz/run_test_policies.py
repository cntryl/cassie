from pathlib import Path
import subprocess,json,sys
attempt=sys.argv[1] if len(sys.argv)>1 else 'test-policy'
root=Path.cwd(); receipts=root/'target/assembly-line/replay-qualification'
manifest=json.loads((root/'docs/testing/replay-qualification-unit-probes-2026-11-17.json').read_text())
paths={f['file'] for f in manifest['files']}
changed=subprocess.check_output(['git','diff','--name-only','48ee5d986f37dd3f47cbcedc58863fb272f4c34a','HEAD'],text=True).splitlines()
paths.update(p for p in changed if p.startswith('tests/') and p.endswith('.rs') and (root/p).exists())
results=[]
for index,path in enumerate(sorted(paths),1):
    label=f'{attempt}-{index:02d}'
    command=[sys.executable,str(receipts/'run_check.py'),label,'cntryl-tools','validate-tests','-f',path]
    status=subprocess.run(command).returncode
    results.append({'file':path,'receipt':label+'.json','exit_code':status})
(receipts/(attempt+'-results.json')).write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'results':results,'status':'passed' if all(r['exit_code']==0 for r in results) else 'failed'},indent=2)+'\n')
raise SystemExit(0 if all(r['exit_code']==0 for r in results) else 1)
