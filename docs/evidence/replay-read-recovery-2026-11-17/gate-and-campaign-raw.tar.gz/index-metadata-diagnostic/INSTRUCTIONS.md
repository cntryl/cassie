# Standalone metadata diagnostic (not a reader repair)

Frozen Cassie source: 66916fee39adc277b27540366200bfa013113110, tree 3308fca2f53958e28b37b6a66d7751b376a5832e.
Probe: /private/tmp/cassie-read-index-metadata-diagnostic-20261117/target/assembly-line/index-metadata-diagnostic/probe.rs
Probe SHA-256: 903bb9b8199429a6f1535e38eff1297f6a4025845a19fbbe539e986627f9c5e5.
Included accepted helper: benches/tier3_replay_durability/read_campaign/store_copy.rs, SHA-256 dcbead3f4f791670220cfb00c076af1f4a8e5a5e8a5509a89aa74a99043f0ffd.

No repository source edits, compilation or execution by coder. The probe is isolated under ignored target. It uses ONLY public Cassie metadata getters and accepted pure receipt/copy helpers. The helper path is relative to this frozen source file; compile this exact path without moving it or changing the include.

## Owner and prerequisite
Assembler compiles/runs only AFTER the current eight-profile campaign is terminal, its complete receipt is preserved and there is no compiler/timing overlap. Reviewer must accept exact probe/helper hashes first. Never open original engines. Originals remain closed/excluded from other openers as required by their trusted manifest closure receipts.

## Link recipe
Use the SAME rustc/toolchain and exact Cassie rlib/dependency artifacts from the frozen 66916 build. Resolve exact filenames from its retained compiler/build fingerprint receipts; do not select an arbitrary glob when multiple hashes exist. Record each artifact SHA-256, frozen source/tree, rustc -vV, command, stdout/stderr and exit status. Include the original native library search/link flags if required by that frozen build. No Cargo/source rebuild by coder, no dependency changes.

With assembler-selected task-specific variables containing those exact paths, the link shape is:

```sh
rustc --edition=2021 --crate-name cassie_index_metadata_probe "$METADATA_PROBE_SOURCE"   -L "dependency=$METADATA_FROZEN_DEPS"   --extern "cassie=$METADATA_CASSIE_RLIB"   --extern "serde=$METADATA_SERDE_RLIB"   --extern "serde_json=$METADATA_SERDE_JSON_RLIB"   --extern "sha2=$METADATA_SHA2_RLIB"   --extern "uuid=$METADATA_UUID_RLIB"   -o "$METADATA_PROBE_BINARY"
"$METADATA_PROBE_BINARY" "$METADATA_FROZEN_MANIFEST" > "$METADATA_OUTPUT_JSONL" 2> "$METADATA_OUTPUT_STDERR"
```

The manifest must be the exact already-verified eight-cell campaign manifest, with its hash retained. All eight raw result/log/closure receipt chains and canonical original identities are checked BEFORE any new copy. It then inspects only the four indexed mode classes. Every engine opens a new private byte-copied directory owned by the accepted helper, using local mode, 64 MiB, 120 seconds and disabled result caching.

## Output and oracle
For each indexed source, output full catalog/native IndexMeta, every native index (no hidden filtering), raw two storage-ID options, target-collection flags and full catalog/native CollectionMeta plus their public storage IDs. Record original fingerprint before copy, after copy and after reader drop, assert all match the bound expected fingerprint. Engine drop/graceful-close attempt is explicitly not native quiescence proof. Remove only each helper-owned temporary copy.

No normalization is performed. The probe does not query/timestamp workloads or claim indexed read qualification. Any mismatch or metadata error is retained and returns nonzero after all selected indexed classes. Actual raw-field disposition must precede a separate doc-first normalization repair and real indexed campaign rerun.
