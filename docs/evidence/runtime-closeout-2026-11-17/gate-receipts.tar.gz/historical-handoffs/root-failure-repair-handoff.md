# B observed-failure repairs

- Base `d1b9c1c630649ab5ffa9aed250260b979f556f71`.
- Ordered range: `940d07fe` selected docs; `0f7c349e` corrected/strengthened
  regressions; `9fab4cde3e6d2b923fa840944fa3a0c2f5282ee6` implementation.
- Final tree `5eb4d7a8f56b71013f395293379ce029c5711c28`.
- Root owns only six paths in this range. No coder/watchdog/COPY/clock edits.
- Observed source test-2: 3904 passed/10 failed, exact d1b9c1c6. Three root
  failures are shared-setting positive, missing-lineage negative and late-latch
  phase error expectation. Full receipt belongs to assembler.
- Source/Jev selected semantics precede implementation in docs. Existing forks
  copy setting/search-path payload, so LOCAL history must stay private too.
  Previous hybrid wrote root restoration history but private value, potentially
  clobbering a legitimate root SET at COMMIT. Fix validates root, then locks
  fork state before updating private history/value. Root clones retain shared
  history; projection mode keeps actual-root transaction freeze.
- Strengthened regression asserts private/root values and histories, then root
  SET persists through COMMIT; ROLLBACK still restores root baseline. Original
  positive failed at visible value, so the strengthened root-SET portion is
  authored/not run and must not be called an observed RED.
- Missing-lineage fixture now explicitly clears automatic captured lineage
  using existing without_operation_failure_authority; expected25000 and kept
  shared namespace are unchanged.
- Late old A->B admitted owner rejects25000 before core; B remains healthy,
  active and same owner, then subsequent B SELECT still gets58030 storage fence.
  Existing current-owner58030 controls remain intact.
- No Cargo/test run. Direct rustfmt and git diff --check passed. All corrected
  controls and affected complete gates remain mandatory/unrun on repair.
