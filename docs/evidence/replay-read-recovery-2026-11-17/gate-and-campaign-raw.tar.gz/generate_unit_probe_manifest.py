from pathlib import Path
import hashlib,importlib.util,json,re,subprocess
root=Path.cwd();base='48ee5d986f37dd3f47cbcedc58863fb272f4c34a'
spec=importlib.util.spec_from_file_location('cassie_inventory',root/'tools/test_inventory.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
paths=subprocess.check_output(['git','diff','--name-only',base,'HEAD'],text=True).splitlines()
records=[]
for name in paths:
    path=root/name
    if not(name.startswith('src/') and path.suffix=='.rs' and path.exists()):continue
    parsed=module.rust_declarations(path)
    if not parsed['tests']:continue
    previous=subprocess.run(['git','show',base+':'+name],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    prior={}
    if previous.returncode==0:
        temp=root/'target/assembly-line/replay-qualification/baseline-source'/name;temp.parent.mkdir(parents=True,exist_ok=True);temp.write_bytes(previous.stdout)
        old=module.rust_declarations(temp)
        prior={(test['name'],tuple(test['inline_modules'])):test for test in old['tests']}
    tests=[]
    for test in parsed['tests']:
        old=prior.get((test['name'],tuple(test['inline_modules'])))
        disposition='added_in_file' if old is None else ('modified_in_file' if old['body']!=test['body'] or old['attributes']!=test['attributes'] else 'retained_in_file')
        tests.append({'name':test['name'],'inline_modules':test['inline_modules'],'line':test['line'],'end_line':test['end_line'],'attributes':test['attributes'],'body_sha256':hashlib.sha256(test['body'].encode()).hexdigest(),'comparison':disposition,'execution_status':'authored/not run'})
    records.append({'file':name,'sha256':hashlib.sha256(parsed['data']).hexdigest(),'lines':len(parsed['data'].splitlines()),'cfg_attributes_in_file':re.findall(r'#!?\[cfg[^\n]*',parsed['data'].decode()),'test_declarations':tests})
flat=[test for record in records for test in record['test_declarations']]
data={'baseline':base,'source_before_inventory_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tree_before_inventory_commit':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'scope':'Static declarations in C-touched src/ Rust files. Existing integration inventory intentionally scans tests/ only. This manifest does not resolve parent module cfg, prove registration, execute tests, or establish observed RED. Comparison is by source file and inline module, not a proof that relocated cases are new behavior.','generator':'tools/test_inventory.py::rust_declarations with pinned tools/test_inventory_requirements.txt; C-touched files selected by git diff from baseline.','file_count':len(records),'declaration_count':len(flat),'added_in_file':sum(test['comparison']=='added_in_file' for test in flat),'modified_in_file':sum(test['comparison']=='modified_in_file' for test in flat),'retained_in_file':sum(test['comparison']=='retained_in_file' for test in flat),'files':records}
out=root/'docs/testing/replay-qualification-unit-probes-2026-11-17.json';out.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({key:data[key] for key in ['file_count','declaration_count','added_in_file','modified_in_file','retained_in_file']},indent=2))
