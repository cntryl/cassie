# Batch B invariant test names

## Scope and identity
- Parent authorized17meaningful names/10files on28677a1f5c2830759030e31c7cd5c44b2bf49958; isolated /private/tmp/cassie-invariant-test-name-repair-20261117 branchcodex/invariant-test-name-repair-20261117.
- Standing testpolicy requires invariant-focused names. No runtime/source-test semantics changed; bodies/attrs/assertions/budgets/synchronization preserved.

## Coder handoff
- Commitfa862675456ab00fc32aa861b99095fd54dc0486 treebab0c654a1bfadf00175e317aff8e32d37851760.
- Observed assemblerpolicy10of41files fail17names solely_and_heuristic; fullstrictClippy3/fmt passed precedingpolicy stage. Those historical outcomes remain onoldsource.
- Only17fn declarationidentifier substitutions in10assignedfiles. rename-map.json exactold→new; body-attribute-equivalence.json proves entirefiles identical after inverseidentifier substitution; references-before.json/references-after.json retained.
- NO executable calls/childselfselector strings referenced these old names. No bodystringexceptions. Onlycurrentgenerated docs/testing/runtime-unit-probes-2026-11-16.json has17oldnames; assembler regenerates afterintegration. Historicalreceipts/reviewidentities untouched.
- Validation git diff --check/sourcebyteequivalence/referencecensus passed. No Cargo/testpolicy tool execution bycoder. Existing assertions and runtime coverage unchanged; no newtest needed for rename-only change.

## Review handoff
- Exact identifier-only source/selector review requested. Metadatahash refresh assembler-owned.

## Assembly and qualification
- Integrate reviewed source, regenerate inventory, repeatrequired affectedpolicy/fmt/hosted activation percoordinator. No test split/ignore/lintlevel bypass/push/PR/merge bycoder.
