import pathlib,json,hashlib,subprocess,os,datetime
R=pathlib.Path('target/assembly-line/replay-qualification').resolve(); I=R/'read-inputs'
exe=pathlib.Path('target/debug/build/cassie/e6e852e886807813/out/tier3_replay_durability-e6e852e886807813').resolve()
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def fingerprint(path,name):
 env=os.environ.copy();env['CASSIE_REPLAY_BENCH_SOURCE_FINGERPRINT']=str(path)
 p=subprocess.run([str(exe)],env=env,capture_output=True,text=True,timeout=120)
 (I/(name+'-fingerprint.log')).write_text(p.stdout+p.stderr)
 assert p.returncode==0,(name,p.stderr)
 j=json.loads(p.stdout);assert j['closure_attested']==False and len(j['fingerprint'])==64
 return j['fingerprint']
source={'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip()}
assert source['commit']=='66916fee39adc277b27540366200bfa013113110'
empty=I/'fingerprint-empty-control';empty.mkdir(exist_ok=True)
assert not list(empty.iterdir())
assert fingerprint(empty,'empty-control')==hashlib.sha256(b'').hexdigest()
fp=[]
for p in pathlib.Path('target/debug/.fingerprint').glob('cassie-*/**/*tier3_replay_durability*'):
 if p.is_file():fp.append({'path':str(p.resolve()),'sha256':sha(p),'bytes':p.stat().st_size})
put(I/'reader-build-identity.json',{'source':source,'build_receipt':str(R/'read-bench-compile.json'),'executable':str(exe),'executable_sha256':sha(exe),'bytes':exe.stat().st_size,'fingerprint_files':fp,'empty_fingerprint_control':'passed','scope':'Trusted local Cargo build provenance, not remote cryptographic attestation.'})
a=json.loads((I/'replacement-api/matrix.json').read_text());assert len(a['outcomes'])==4 and all(x['status']=='passed' and x['exit_code']==0 for x in a['outcomes'])
b=json.loads(pathlib.Path('/private/tmp/cassie-all-open-runtime-integration-20261116/target/assembly-line/runtime-closeout/sql8-closed-stores.json').read_text())
api=a['writer'];sql={'commit':b['inputs'][0]['writer_source'],'tree':b['inputs'][0]['writer_tree']}
profiles=[];identity=[];seen=set()
for group,items,writer in [('new-replacement-api',a['outcomes'],api),('retained-B-sql',b['inputs'],sql)]:
 for x in items:
  name=x['name'];rp=pathlib.Path(x.get('result_path',x.get('writer_raw_receipt')));lp=pathlib.Path(x.get('log_path',str(rp.with_suffix('.log'))))
  rs=x.get('result_sha256',x.get('writer_raw_sha256'));ls=x.get('log_sha256',x.get('writer_log_sha256'))
  assert sha(rp)==rs and sha(lp)==ls
  raw=json.loads(rp.read_text());store=pathlib.Path(raw['storage_path']);canonical=store.resolve(strict=True)
  assert canonical not in seen;seen.add(canonical)
  assert raw['events']==100000 and raw['batch_size']==1000 and raw['batch_count']==100
  closure=I/(name+'-closure.json')
  put(closure,{'writer':writer,'storage_path':raw['storage_path'],'exit_code':0,'clean_closed':True,'result_sha256':rs,'log_sha256':ls,'basis':'Actual producer process exited zero after source-backed clean-reopen assertions; trusted exclusion of later openers, not native/background quiescence.','generation':group})
  profile={'result_path':str(rp),'result_sha256':rs,'log_path':str(lp),'log_sha256':ls,'closure_path':str(closure),'closure_sha256':sha(closure),'source_fingerprint':fingerprint(store,name)}
  profiles.append(profile);identity.append({'name':name,'generation':group,'writer':writer,'storage_path':str(store),'canonical_storage_path':str(canonical),'producer_exit_code':0,**profile})
manifest=I/'read-manifest.json'
assert not manifest.exists()
put(manifest,{'format':'cassie-replay-read-v1','reader':source,'reader_build_profile':'test','api_writer':api,'sql_writer':sql,'profiles':profiles})
put(I/'writer-identity-map.json',{'manifest':str(manifest),'manifest_sha256':sha(manifest),'profiles':identity,'historical_A_stores':'missing; original raw measurements preserved, four fresh exact-A replacements explicitly separate'})
print(json.dumps({'manifest':str(manifest),'sha256':sha(manifest),'profiles':len(profiles),'reader':source}))
