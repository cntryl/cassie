from pathlib import Path
import json,hashlib,subprocess,os,time,datetime,signal
root=Path.cwd();base=root/'target/assembly-line/replay-qualification';proof=json.loads((base/'read-inputs/retained-a-producer/proof.json').read_text());exe=Path(proof['preserved_binary']);out=base/'read-inputs/replacement-api';out.mkdir(parents=True,exist_ok=True)
if (out/'matrix.json').exists():raise SystemExit('Refuse to overwrite an earlier replacement generation')
stores=out/'retained-stores';stores.mkdir();source=proof['writer'];label=source['commit']+';tree='+source['tree']+';profile=test;feature=replay-benchmark-observation';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],text=True)
plan={'generation':'fresh-api-read-input-replacement-2026-11-17-v1','purpose':'Four newly generated reader inputs; separate from all historical A measurements. No full writer matrix rerun.','writer':source,'orchestrator_head':head,'binary_sha256':proof['binary_sha256'],'command':[str(exe)],'actual_build_profile':'test','query_memory_budget_bytes':67108864,'query_timeout_ms':120000,'process_hang_guard_seconds':1800,'outcomes':[]};receipt=out/'matrix.json';receipt.write_text(json.dumps(plan,indent=2)+'\n')
for shape in ['indexed','unindexed']:
 for mode in ['local_strict','local_buffered']:
  assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
  assert hashlib.sha256(exe.read_bytes()).hexdigest()==proof['binary_sha256']
  name='fresh-api-'+shape+'-'+mode+'-1000x100';env=os.environ.copy();env.update(TMPDIR=str(stores.resolve()),CASSIE_REPLAY_BENCH_SOURCE=label,CASSIE_REPLAY_BENCH_MODE=mode,CASSIE_REPLAY_BENCH_SHAPE=shape,CASSIE_REPLAY_BENCH_WORKLOAD='apply',CASSIE_REPLAY_BENCH_BATCH_SIZE='1000',CASSIE_REPLAY_BENCH_BATCHES='100')
  item={'name':name,'mode':mode,'shape':shape,'status':'running','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment_selectors':{k:v for k,v in env.items() if k.startswith('CASSIE_REPLAY_BENCH_') or k=='TMPDIR'}};plan['outcomes'].append(item);receipt.write_text(json.dumps(plan,indent=2)+'\n');print('START',name,flush=True);start=time.monotonic();log=out/(name+'.log')
  with log.open('wb') as stream:
   proc=subprocess.Popen([str(exe)],cwd='/private/tmp/cassie-all-open-integration-20261116',env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=proc.wait(timeout=1800);status='passed' if code==0 else 'failed'
   except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait();code=proc.returncode;status='timed_out_killed_reaped'
  item.update(exit_code=code,status=status,elapsed_seconds=time.monotonic()-start,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_path=str(log))
  if code==0:
   try:
    candidates=[]
    for line in log.read_bytes().splitlines(keepends=True):
     try:
      data=json.loads(line)
      if isinstance(data,dict) and data.get('source')==label:candidates.append((line,data))
     except (ValueError,UnicodeDecodeError):pass
    assert len(candidates)==1
    line,data=candidates[0]
    expected={'source':label,'mode':mode,'shape':shape,'workload':'apply','batch_size':1000,'batch_count':100,'events':100000,'submitted_events':100000,'applied_events':100000,'query_memory_budget_bytes':67108864,'query_timeout_ms':120000,'selected_primary_policy':'local_sync' if mode=='local_strict' else 'local_buffered'}
    for key,value in expected.items():assert data[key]==value,(key,data[key],value)
    assert len(data['samples'])==100
    assert all(x['foreground_native_commits']['first_policy']==expected['selected_primary_policy'] for x in data['samples'])
    store=Path(data['storage_path']);assert store.is_dir() and store.resolve().is_relative_to(stores.resolve())
    raw=out/(name+'.json');raw.write_bytes(line);item.update(result_path=str(raw),result_sha256=hashlib.sha256(line).hexdigest(),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),storage_path=data['storage_path'],observed_producer_exit_zero=True,source_known_clean_reopen_assertions='passed',source_per_batch_API_report_assertions='passed')
   except Exception as error:item.update(status='failed_validation',validation_error=repr(error));code=1
  receipt.write_text(json.dumps(plan,indent=2)+'\n');print('END',name,item['status'],round(item['elapsed_seconds'],2),flush=True)
  if code:print(log.read_text(errors='replace')[-12000:],flush=True);raise SystemExit(code or 1)
plan.update(status='passed',controls_passed=len(plan['outcomes']),ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());receipt.write_text(json.dumps(plan,indent=2)+'\n');print('FOUR FRESH API INPUTS PASSED',flush=True)
